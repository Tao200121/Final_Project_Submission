/*
 * structs.h
 *
 *  Created on: Apr 21, 2022
 *      Author: brucytao200121
 */

#ifndef SRC_HEADER_FILES_STRUCTS_H_
#define SRC_HEADER_FILES_STRUCTS_H_

struct platform{
  int x_min;
  int x_max;
  int length;
  int y_position;
  float v;
  float acceleration;
  float platform_mass;
  float force;
  unsigned energy;
  int booster_ready_yet;
};

struct ball{
  int num_of_balls;
  unsigned diameter;
  int ball_x_position;
  int ball_y_position;
  unsigned mass;
  float vx;
  float vy;
};

struct shield{
  unsigned ke_reduction;
  unsigned boost;
  unsigned ke_increase;
  unsigned recharge_time;
};

#endif /* SRC_HEADER_FILES_STRUCTS_H_ */
