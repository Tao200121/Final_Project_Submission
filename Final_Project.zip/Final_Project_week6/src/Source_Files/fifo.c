/*
 * fifo.c
 *
 *  Created on: Mar 5, 2022
 *      Author: Lena Hunicke-Smith
 */


#include "fifo.h"

